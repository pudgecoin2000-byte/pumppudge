// Supported wallet providers
const walletProviders = {
  Phantom: {
    isInstalled: () => window.solana && window.solana.isPhantom,
    connect: async () => window.solana.connect(),
    getAddress: resp => resp.publicKey.toString(),
    installUrl: "https://phantom.app/"
  },
  Solflare: {
    isInstalled: () => window.solflare && window.solflare.isSolflare,
    connect: async () => window.solflare.connect(),
    getAddress: resp => resp.publicKey.toString(),
    installUrl: "https://solflare.com/"
  },
  Backpack: {
    isInstalled: () => window.backpack && window.backpack.isBackpack,
    connect: async () => window.backpack.connect(),
    getAddress: resp => resp.publicKey.toString(),
    installUrl: "https://www.backpack.app/"
  },
  Ledger: {
    isInstalled: () => window.ledger && window.ledger.isLedger,
    connect: async () => window.ledger.connect(),
    getAddress: resp => resp.publicKey.toString(),
    installUrl: "https://www.ledger.com/"
  }
};

function abbreviateAddress(address) {
  return address ? address.substring(0, 4) + '...' + address.substring(address.length - 4) : '';
}

function setupWalletButton(btnId, infoId, selectId) {
  const btn = document.getElementById(btnId);
  const info = document.getElementById(infoId);
  const select = document.getElementById(selectId);

  btn.onclick = async function() {
    const wallet = select.value;
    const provider = walletProviders[wallet];
    if (!provider) return alert('Wallet not supported.');
    if (provider.isInstalled()) {
      try {
        const resp = await provider.connect();
        const address = provider.getAddress(resp);
        btn.classList.add('connected');
        btn.textContent = "Wallet Connected";
        btn.disabled = true;
        select.disabled = true;
        info.style.display = "inline-block";
        info.className = "wallet-address";
        info.textContent = abbreviateAddress(address);
      } catch (err) {
        alert("Wallet connection canceled or failed.");
      }
    } else {
      alert("Please install the " + wallet + " wallet extension to connect your Solana wallet.");
      window.open(provider.installUrl, "_blank");
    }
  };
}

// Setup desktop and mobile connect wallet buttons
setupWalletButton("connect-wallet-btn", "wallet-info", "wallet-select");
setupWalletButton("connect-wallet-btn-mobile", "wallet-info-mobile", "wallet-select-mobile");

// Navigation and copy contract logic unchanged
document.addEventListener('DOMContentLoaded', function() {
  var navToggle = document.getElementById('nav-toggle');
  var navLinks = document.getElementById('nav-links');
  if(navToggle && navLinks) {
    navToggle.addEventListener('click', function() {
      var isOpen = navLinks.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      if (isOpen) {
        navLinks.querySelector('a').focus();
        document.body.style.overflowY = 'hidden';
      } else {
        document.body.style.overflowY = '';
      }
    });
    document.addEventListener('click', function(e) {
      if (navLinks.classList.contains('open') && !navLinks.contains(e.target) && e.target !== navToggle) {
        navLinks.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflowY = '';
      }
    });
    document.addEventListener('keydown', function(e){
      if (e.key === 'Escape' && navLinks.classList.contains('open')) {
        navLinks.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflowY = '';
        navToggle.focus();
      }
    });
  }
  var copyBtn = document.getElementById('copy-ca-btn');
  var caText = document.getElementById('contract-addr');
  if(copyBtn && caText) {
    copyBtn.addEventListener('click', function() {
      var addr = caText.textContent.replace(/^CA:\s*/, '').trim();
      navigator.clipboard.writeText(addr).then(function(){
        copyBtn.classList.add('copied');
        copyBtn.textContent = 'Copied!';
        setTimeout(function(){
          copyBtn.classList.remove('copied');
          copyBtn.textContent = 'Copy';
        }, 1200);
      });
    });
  }
  function handleFirstTab(e) {
    if (e.key === "Tab") {
      document.body.classList.add('user-is-tabbing');
      window.removeEventListener('keydown', handleFirstTab);
    }
  }
  window.addEventListener('keydown', handleFirstTab);
});